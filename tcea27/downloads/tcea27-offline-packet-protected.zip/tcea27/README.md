# TCEA 2027 · MG Learn conference companion

Published at https://mglearn.github.io/tcea27/ from `mglearn/mglearn.github.io`, main branch root. Published workshops are **High-Impact Teaching Math Tools Without the Price Tag** and **Project Management and Change Leadership**, each designed for fifty minutes. The original math workshop is **High-Impact Teaching Math Tools Without the Price Tag**. Its stable path remains `sessions/math-without-price-tag/`.

## Maintain the site

Canonical session, resource, strategy, experience, download and lesson records live in `data/*.json`. Static pages are generated so navigation and explanations also work without JavaScript. `site-data.js` is a generated local snapshot, allowing extracted `file://` use without fetch or a web server. No runtime packages, trackers, cookies, or external fonts are used. The protected webdeck uses the canonical Web Deck v5 framework and stores only slide position and speaker-notes text size. Participant reflections remain in memory.

- Edit JSON, `assets/css/`, `assets/js/`, or the page compositions in `scripts/build.py`.
- Run `python3 tcea27/scripts/build-downloads.py` from the repository root (requires Python ReportLab only for PDF authoring). It regenerates static pages, PDFs, HTML companions, datasets, QR code, and the offline ZIP.
- Run `python3 tcea27/scripts/verify.py` to check paths, data, downloads, and research provenance. Browser checks live in `tests/`; see `tests/README.md`.
- Serve the repository root with `python3 -m http.server 4227`; visit `/tcea27/`.
- Review changes, commit and push main; verify GitHub Pages and the live site.

## Add a workshop

1. Add a unique `id` and `slug` in `data/sessions.json`, initially with `status: "draft"`. Follow the existing record's fields, including audience, presenters, learning objectives, tool/strategy IDs, activities, resources, and completed downloads.
2. Create `sessions/<slug>/index.html` and any workshop-specific activities and presenter materials. Keep references relative to `/tcea27/`. Use shared styles and components. The first session's build functions illustrate the structure; avoid copying private facilitation notes.
3. Add resource and strategy records and their related session IDs. Research values must be verified from a primary source, with date and interpretation notes; use null for values that cannot be verified. The card component supports missing values without inventing a number.
4. Create and check every linked download. Keep incomplete sessions out of navigation by leaving them draft.
5. Mark the session published, run the build and checks, then commit/push. The home card grid grows from the published session records without a layout redesign. The first math session has a dedicated illustrated card; future subjects can customize its visual treatment in `session_card`.

## Evidence and availability

Seven MetaX influence records were reviewed October 27, 2026, version 1.4 (February 2026). The reported statistic is **Weighted mean effect size**, which can differ from the record's meta-analysis table average. Corrective feedback maps to the broader Feedback influence. Retrieval practice maps to Practice testing. These values describe research on strategies, not these tools. The `strategies.json` records include URLs, domains, definitions, examples and limitations.

TEKS correlations are paraphrased from TEA's current Chapter 111 elementary, middle-school and high-school PDFs (links in `lessons.json`). Kindergarten joining/separating, Grade 3 categorical graphs, Grade 6 distributions and Algebra I data relationships were checked. This does not certify a complete curriculum alignment. Digital Math Tools' five grade-band collections and the GraphSplat/Quiz tool pages were verified as published.

The presenter guide and 20-slide webdeck are AES-256-GCM encrypted with a PBKDF2-SHA256 password-derived key (600,000 iterations). Only ciphertext is published in the current site, offline packet, and deck library. Passwords and decrypted HTML are held only in memory; earlier public Git revisions and previously downloaded packets remain public. Attendee answer explanations start collapsed. Timers are optional, text-only and do not flash or play sound. No leaderboard or learning-gain claim is made.

## Offline and accessible formats

Download/extract the packet and open `tcea27/index.html`. Local graphs, native explanation disclosures, interactions, reflection copying (with fallback), presenter controls and PDFs work without internet. External tools/research need connectivity. Print styles expose attendee answer keys and, after password entry, the presenter segments. The webdeck exports audience slides without speaker notes. Its standard framework stores only slide position and notes font size. The five PDFs have selectable text and complete semantic HTML alternatives; they are not claimed to be tagged PDF/UA. Reflections remain in memory, clearing on reload; copy or print to preserve them.

Original teaching materials may be reused and adapted with attribution to Miguel Guhlin / MG Learn. Third-party research, standards and linked resources retain their respective rights. The visual design draws inspiration from the convention site's hierarchy and the requested navy/blue/gold palette; it includes original graphics and no copied TCEA artwork or logo.

## Protected presenter authoring

Private HTML sources and the password file must live outside this public repository. The local private source directory is recorded in the separate release notes, not published. Seal an updated guide or deck using `node tcea27/scripts/seal-presenter.cjs <private-html> <private-password-file> <public-output-html>`, then rebuild the offline packet. The build refuses to regenerate an unprotected guide. Never add plaintext presenter notes or a password to public JSON, scripts, PDFs, screenshots, or Git. Browser tests requiring presenter access read `TCEA_PASSWORD_FILE`; they never log the password.

The protected deck is also mirrored at https://mguhlin.github.io/webdecks/tcea27/math-tools.html . It follows the canonical Web Deck v5 specification with project-local framework copies in `assets/webdeck/` and inlined copies in the encrypted HTML. Twenty slides allocate exactly fifty minutes and contain roughly 100-word teleprompter notes each. Slide links open activities and demonstrations in separate tabs. `V` opens the synchronized presenter window with resizable notes, `F` fullscreen, `S` local notes, and `P` slide PDF export. On HTTPS, a presenter window opened from an already-open deck can inherit that decrypted document in memory using a same-origin/opener-checked message; nothing is persisted. Offline presenter windows may ask for the password again.

## Saved TCEA27 visual identity

Use [TCEA27 Learning Adventure](design-system/README.md) for future sessions. The design-system folder contains the theme manifest, approved desktop/mobile references, and a starter body template. Project `AGENTS.md` records the design rules for future work. Create a landing page from a real draft session record using `python3 tcea27/scripts/create-session.py <session-id>`. The scaffold reuses the shared page shell and stylesheet; no new session theme is needed.

## Two current sessions

The homepage uses a manual image carousel driven by published records in `data/sessions.json`. It supports next/previous controls, labeled dots, keyboard arrows, swipe, no autoplay, and a readable no-JavaScript list. Math-specific follow-up cards and ACE content live on the math session page. The user-approved homepage header/hero/ribbon is unchanged and guarded by its saved markup hash and screenshot.

Project Management is a focused conference adaptation of the supplied four-hour Module 8 assets, using the fictional portable-classroom case. It includes a six-segment agenda, content models, individual thinking, neighbor discussions, a memory-only next-step planner, four PDF/HTML resources, and encrypted presenter guide/deck. The source module's proposed videos and archived slide screenshots are not presented as completed new conference assets. Primary ADKAR and Kotter references were checked. The public build helper is `scripts/project_management.py`. Both workshops have twenty-slide protected decks with facilitator second, overview, success criteria, a photorealistic title image, and original SVG infographics, using the shared deck theme and renderer.

## Beyond the Rollout revision

The second workshop is **Beyond the Rollout: Project Management That Works in K–12**. Keep its stable project-management URLs. It is presenter-led: no project, preparation, or device is required. Teach through the shared portable-classroom case and completed framework, with brief seated decision discussions. Its six agenda blocks are 0–5, 5–15, 15–27, 27–40, 40–47, and 47–50. Reusable templates are takeaways. The ADKAR, Kotter, KPI, milestone, and risk infographics are generated by `scripts/pm_infographics.py`; model terminology and paraphrased summaries link to primary sources. The folder’s Custom-Instructions-TCEA-Infographic-Slide-Decks.txt supplied infographic layout guidance, not images to import. The existing Module 8.1 deck was inspected as a visual reference; its privacy content and module label are not reused.

The math deck now applies the infographic instructions to its own content: number-line arrows, graph-scale comparison, graph choice, sampling, argumentation, retrieval/feedback, and ACE. Private notes and fifty-minute timing are preserved. Warm, direct language is the default in the saved deck guidelines and canonical webdeck instructions.

## Remembered presenter access and explanatory photo slides

The current gate offers Remember access on this browser for 30 days. An opaque SameSite=Strict cookie identifies a non-exportable PBKDF2 CryptoKey in IndexedDB. Passwords and decrypted HTML are not persisted. Keys are origin-scoped: unlock once per host. Forget access and lock clears keys and the cookie. Unchecked access remains temporary; extracted file access does not persist. Expiration is checked in storage as well as cookie lifetime. The remember-access browser test covers restart, cross-workshop access, non-exportability, expiration, and removal. Previously written reload-lock descriptions apply to temporary access.

Project Management slide six pairs generated illustrative problem/scope photos. Slides seven through twenty combine fictional school photos and full action/evidence explanations, including ADKAR and Kotter; avoid unexplained labels such as map handoffs. The reusable CSS is assets/webdeck/tcea27-photo-teaching.css. Math content uses its own infographic CSS and diagrams, with an accurate arrowed number line.

## Play, Explore, Explain · third workshop

**Play, Explore, Explain: Cooperative Learning in Action** is published at `sessions/play-explore-explain/`. Its twenty-slide protected deck lasts exactly fifty minutes: play 0–9, connect 9–18, explore 18–34 (two eight-minute rounds), share 34–42, adapt 42–47, check 47–50. Small groups share a goal and rotate contributions; attendees bring a device, with shared-device and printed alternatives. All six requested SplatWorks tools have task cards and original starter files. Bingo Generator and Caller are linked separately; a Caller room name does not synchronize remote devices. No unsupported live-room claim is made.

The public generator is `scripts/cooperative_learning.py`; precise SVG visuals come from `scripts/cooperative_visuals.py`; data is in `data/cooperative-learning.json`. Notes and deck sources remain private. Four selectable-text PDFs have semantic HTML alternatives. Browser notes and Bingo marks stay in memory; no answers are submitted. The resource library and carousel now include three workshops. New strategy records carry null effect sizes and primary EEF/IES sources; the existing math handout stays limited to its seven strategies.

Warm voice and a purposeful photo or infographic on every slide are required. Use varied visual forms—timeline, role map, Bingo example, connected routine, tool pathways, and explanatory photo panels. Keep generated-image disclosures on the website, access actions in presenter controls, and the approved homepage hero unchanged.
